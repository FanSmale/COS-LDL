clear all;
clc;
%% Load the trainData and TestData.
%load Movie2;
load Yeast_alpha;
%load Yeast_cdc;
%load Yeast_elu;
%load Yeast_diau;
%load Yeast_heat;
%load Yeast_spo;
%load Yeast_cold;
%load Yeast_dtt;
%load Yeast_spo5;
%load Yeast_spoem;


for rep=1:10   
    feature=features;
    label=labels;
    r=randperm(size(feature,1) );
    [cow,row]=size(feature);
    feature = feature(r,:);
    label = label(r,:);
    trainFeature = feature(1:round(cow*0.8),:);
    trainDistribution=label(1:round(cow*0.8),:);
    testFeature = feature(round(cow*0.8)+1:cow,:);
    testDistribution=label(round(cow*0.8)+1:cow,:);
    
    %save movie.mat  feature testDistribution testFeature trainFeature trainDistribution;
    save alpha.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save cdc.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save elu.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save diau.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save heat.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save spo.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save cold.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save dtt.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save spo5.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %save spoem.mat  feature testDistribution testFeature trainFeature trainDistribution;
    %size(trainFeature,2)  return trainFeature����2045��eye��A,B�����Խ���1������0��
    %item 2045*5 ���Խ���1 ����0
    
   
   
    % The training part of edl algorithm.
    tic;
     item=eye(size(trainFeature,2),size(trainDistribution,2));
    % The function of bfgsprocess provides a target function and the gradient.
    [weights,fval] = cosldltrain(@cosldlprogress,item);
    fprintf('Training time of COS-LDL: %8.7f \n', toc);
    % Prediction
    preDistribution = lldPredict(weights,testFeature);
    fprintf('Finish prediction of COS-LDL. \n');
    cd('./measures');
    % To visualize two distribution and display some selected metrics of distance
    for i=1: cow-round(cow*0.8)
        dist(i,1)=euclideandist(testDistribution(i,:), preDistribution(i,:));
        dist(i,2)=sorensendist(testDistribution(i,:), preDistribution(i,:));
        dist(i,3)=squaredxdist(testDistribution(i,:), preDistribution(i,:));
        dist(i,4)=kldist(testDistribution(i,:), preDistribution(i,:));
            if dist(i,4)>1
        dist(i,4)=0.0000001;
            end
        dist(i,5)=intersection(testDistribution(i,:), preDistribution(i,:));
        dist(i,6)=fidelity(testDistribution(i,:), preDistribution(i,:));
        dist(i,7)=clark(testDistribution(i,:), preDistribution(i,:));
        dist(i,8)=innerProduct(testDistribution(i,:), preDistribution(i,:));
        dist(i,9)=cosine(testDistribution(i,:), preDistribution(i,:));
        dist(i,10)=canberra(testDistribution(i,:), preDistribution(i,:));
    end
    cd('../');
    
    
    
    [cow,row]=size(testDistribution);
    %% real distribution
    for i=1:cow
        for j=1:row
            if testDistribution(i,j)<1/row
                test_target(i,j)=-1;
            else   test_target(i,j)=1;
            end
        end
    end
    

    
    %% 10 measures
    for i=1:10
        mea(i,rep)=mean(dist(:,i));
        stda(i,rep)=std(dist(:,i));
    end
    
    [cow,row]=size(mea);
    for i=1:cow
        meanres(i)=mean(mea(i,:));
        stdres(i)=std(stda(i,:));
    end
    
end