function [disName distance] = computeMeasures(testDistribution, preDistribution)
%COMPUTEMEASURES        computes different measures between two distributions.
%
%	Description
%   [DISNAME, DISTANCE] = COMPUTEMEASURES(TESTDISTRIBUTION,PREDISTRIBUTION) 
%   computes different measures between tested distributions and  predicted distributions.
%
%   Inputs,
%       TESTDISTRIBUTION:  the matrix of tested distributions  with instances in rows (m x k)
%       PREDISTRIBUTION:  the matrix of predicted distributions with instances in rows (m x k)
%
%   Outputs,
%       DISNAME:   the name of selected measures.
%       DISTANCE:  mean values of selected measures

%
disName = {'euclideandist','sorensendist','squaredChord','kldist','intersection','fidelity','clark','canberra','cosine','innerProduct',};

distance = zeros(1,10);
% compute Measurements
cd('./measures');
distance(1,1)=euclideandist(testDistribution, preDistribution);
distance(1,2)=sorensendist(testDistribution, preDistribution);  
distance(1,3)=squaredChord(testDistribution, preDistribution);
distance(1,4)=kldist(testDistribution, preDistribution);
distance(1,5)=intersection(testDistribution, preDistribution);
distance(1,6)=fidelity(testDistribution, preDistribution);
distance(1,7)=clark(testDistribution, preDistribution);
distance(1,8)=canberra(testDistribution, preDistribution);  
distance(1,9)=cosine(testDistribution, preDistribution);
distance(1,10)=innerProduct(testDistribution, preDistribution);
cd('../');
end

