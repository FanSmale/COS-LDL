There are 4 part of our project
cosldldemo.m      : The main part of our project
cosldltrain.m     : The training part of our project
cosldlprogress.m  : Construction of Objective Function and Gradient Solution
fminlbfgs         : The L-BFGS method

Dataset��
No.	Dataset	        #Instances(n)	#Features(q)	#Labels(c)
1	Yeast-alpha	2,465	        24	         18
2	Yeast-cdc	2,465	        24	         15
3	Yeast-elu	2,465	        24	         14
4	Yeast-diau	2,465	        24	          7
5	Yeast-heat	2,465	        24	          6
6	Yeast-spo	2,465	        24	          6
7	Yeast-cold	2,465	        24	          4
8	Yeast-dtt	2,465	        24	          4

The rest of the files in this compressed file are copyrighted by Professor Xin Geng and Professor Xiu-Yi Jia. See readme2 for more details
